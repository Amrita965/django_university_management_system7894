from django.urls import path
from . import views

urlpatterns = [
    path('', views.adminLogin, name="adminLogin"),
    path('home/', views.home, name="home"),
    path('student/', views.studentReg, name="student_registration"),
    path('show_student_data/', views.displayStudentInfo, name="studentdata"),
    path('delete_student_data/<int:id>', views.deleteStudentData, name="deletestudentdata"),
    path('edit_student_info/<int:id>', views.editStudentData, name="editstudentdata"),
    path('update_student_info/<int:id>', views.updateStudentInfo, name="editstudentdata"),
    
    path('teacher/', views.teacherReg, name="student_registration"),
    path('show_teacher_data/',views.displayTeacherInfo),
    path('delete_teacher_data/<int:id>', views.deleteTeacherData, name="deletestudentdata"),
    path('edit_teacher_info/<int:id>', views.editTeacherData, name="editstudentdata"),
    path('update_teacher_info/<int:id>', views.updateTeacherInfo, name="editstudentdata"),


]
