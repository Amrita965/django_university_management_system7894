from django.db import models

# Create your models here.

class Admin(models.Model):
    email = models.EmailField(max_length=50)
    password = models.CharField(max_length=20)


class Student(models.Model):
    firstName = models.CharField(max_length=15)
    lastName = models.CharField(max_length=15)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    address = models.TextField(max_length=150)
    department = models.CharField(max_length=40)
    gender = models.CharField(max_length=6)


class Teacher(models.Model):
    firstName = models.CharField(max_length=15)
    lastName = models.CharField(max_length=15)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    address = models.TextField(max_length=150)
    department = models.CharField(max_length=40)
    gender = models.CharField(max_length=6)