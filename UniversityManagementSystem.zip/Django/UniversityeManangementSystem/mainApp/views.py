import email
from django.shortcuts import render, redirect 
from . models import Admin, Student, Teacher


# Create your views here.

def adminLogin(request):
    if request.method == "POST":
        email = request.POST["email"]
        password = request.POST["password"]
        ob = Admin.objects.get(password="admin")

        if ob.email == email and ob.password == password:
            return render(request, 'home.html')


    return render(request, 'admin.html')

def home(request):
    return render(request, 'home.html')

def studentReg(request): 
    if request.method == "POST":
        firstName = request.POST["fname"]
        lastName = request.POST["lname"]
        email = request.POST["email"]
        phone = request.POST["phone"]
        address = request.POST["address"]
        department = request.POST["department"]
        gender = request.POST["gender"]
       
        obj = Student(firstName=firstName, lastName=lastName, email=email, phone=phone, address=address, department=department, gender=gender)
        obj.save()
        
    return render(request, 'student_registration.html')

def displayStudentInfo(request):  
    students = Student.objects.all()  
    return render(request,"student_data.html",{'students':students})

def deleteStudentData(request, id):  
    student = Student.objects.get(id=id)  
    student.delete()  
    return redirect("/show_student_data/")  

def editStudentData(request, id):  
    student = Student.objects.get(id=id)  
    return render(request,'update_student_info.html', {'student':student})  
    
def updateStudentInfo(request, id):  
    if request.method == "POST": 
        student = Student.objects.get(id=id)    
        student.firstName = request.POST["fname"]
        student.lastName = request.POST["lname"]
        student.email = request.POST["email"]
        student.phone = request.POST["phone"]
        student.address = request.POST["address"]
        student.department = request.POST["department"]
        student.gender = request.POST["gender"]
        student.save()
        return redirect("/show_student_data/")



def teacherReg(request): 
    if request.method == "POST":
        firstName = request.POST["fname"]
        lastName = request.POST["lname"]
        email = request.POST["email"]
        phone = request.POST["phone"]
        address = request.POST["address"]
        department = request.POST["department"]
        gender = request.POST["gender"]
       
        obj = Teacher(firstName=firstName, lastName=lastName, email=email, phone=phone, address=address, department=department, gender=gender)
        obj.save()
        
    return render(request, 'teacher_registration.html')

def displayTeacherInfo(request):  
    teacher = Teacher.objects.all()  
    return render(request,"teacher_data.html",{'teachers':teacher})

def deleteTeacherData(request, id):  
    teacher = Teacher.objects.get(id=id)  
    teacher.delete()  
    return redirect("/show_teacher_data/")  

def editTeacherData(request, id):  
    teacher = Teacher.objects.get(id=id)  
    return render(request,'update_teacher_info.html', {'teacher':teacher})  

def updateTeacherInfo(request, id):  
    if request.method == "POST": 
        teacher = Teacher.objects.get(id=id)    
        teacher.firstName = request.POST["fname"]
        teacher.lastName = request.POST["lname"]
        teacher.email = request.POST["email"]
        teacher.phone = request.POST["phone"]
        teacher.address = request.POST["address"]
        teacher.department = request.POST["department"]
        teacher.gender = request.POST["gender"]
        teacher.save()
        return redirect("/show_teacher_data/")